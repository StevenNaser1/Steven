/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmihello;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import javax.naming.NamingEnumeration;

/**
 *
 * @author steve
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NotBoundException, MalformedURLException, RemoteException {
      HelloService service = (HelloService) Naming.lookup("rmi://localhost:5099/hello");    
        System.out.println("----" + service.echo("Hey server") + " \n Service Name: " + service.getClass().getName());
}
}
